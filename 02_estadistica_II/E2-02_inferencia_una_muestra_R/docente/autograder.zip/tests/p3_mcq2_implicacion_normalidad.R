test = list(
  name = "p3_mcq2_implicacion_normalidad",
  cases = list(
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0,
      code = {
        testthat::expect_true(exists("respuesta_mcq2"), info = "Guarde su respuesta en respuesta_mcq2.")
        testthat::expect_true(is.character(respuesta_mcq2) && toupper(trimws(respuesta_mcq2)) %in% c("A", "B", "C", "D"), info = "La respuesta debe ser una letra entre A y D, por ejemplo \"B\".")
      }
    ),
    ottr::TestCase$new(
      hidden = TRUE,
      name = NA,
      points = 1,
      code = {
        testthat::expect_equal(toupper(trimws(respuesta_mcq2)), if (shapiro.test(muestra$gramaje_tela)$p.value >= 0.05) "C" else "B")
      }
    )
  )
)