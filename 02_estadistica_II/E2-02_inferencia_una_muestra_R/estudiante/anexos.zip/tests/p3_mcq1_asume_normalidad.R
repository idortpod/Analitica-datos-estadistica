test = list(
  name = "p3_mcq1_asume_normalidad",
  cases = list(
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0,
      code = {
        testthat::expect_true(exists("respuesta_mcq1"), info = "Guarde su respuesta en respuesta_mcq1.")
        testthat::expect_true(is.character(respuesta_mcq1) && toupper(trimws(respuesta_mcq1)) %in% c("A", "B", "C", "D"), info = "La respuesta debe ser una letra entre A y D, por ejemplo \"B\".")
      }
    )
  )
)