test = list(
  name = "p3_mcq10_diseno_estudio",
  cases = list(
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0,
      code = {
        testthat::expect_true(exists("respuesta_mcq10"), info = "Guarde su respuesta en respuesta_mcq10.")
        testthat::expect_true(is.character(respuesta_mcq10) && toupper(trimws(respuesta_mcq10)) %in% c("A", "B", "C", "D"), info = "La respuesta debe ser una letra entre A y D, por ejemplo \"B\".")
      }
    )
  )
)