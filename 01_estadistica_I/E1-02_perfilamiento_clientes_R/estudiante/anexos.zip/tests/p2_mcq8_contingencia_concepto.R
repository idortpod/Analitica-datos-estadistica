test = list(
  name = "p2_mcq8_contingencia_concepto",
  cases = list(
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0,
      code = {
        testthat::expect_true(exists("respuesta_mcq8"), info = "Guarde su respuesta en respuesta_mcq8.")
        testthat::expect_true(is.character(respuesta_mcq8) && toupper(trimws(respuesta_mcq8)) %in% c("A", "B", "C", "D"), info = "La respuesta debe ser una letra entre A y D, por ejemplo \"B\".")
      }
    )
  )
)